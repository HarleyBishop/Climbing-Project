# APEX — Beta Board visual restyle kit

A small, focused package for restyling an existing UI into the **APEX** look:
**near-black canvas, one electric-lime accent, Space Grotesk + Space Mono,
hairline rules, oversized numerals, ambient lime glow.** Super-modern, technical, high-contrast.

> **Goal:** apply this *visual language* to your existing screens. Keep your own
> components, routing, and data — change the tokens, type, and the handful of
> signature treatments below. This is a skin, not a rewrite.

---

## 1. Design tokens

Drop these into your theme / CSS variables. Every value in the prototype comes from here.

```
/* Surfaces (darkest → lightest) */
--page:   #070809;   /* behind everything */
--bg:     #0B0C0F;   /* app background / content */
--panel:  #101217;   /* modals, raised header band */
--card:   #16181E;   /* cards */
--raise:  #1C1F26;   /* inputs, pills, segmented controls, avatars */

/* Text */
--ink:    #F5F6F3;   /* primary */
--ink2:   #8B919C;   /* secondary */
--ink3:   #5A5F69;   /* tertiary / placeholder / mono labels */

/* Accent — the ONE color. Use sparingly but confidently. */
--lime:     #D6FF3E; /* primary actions, highlights, active states */
--lime-d:   #b6e02f; /* gradient end */
--lime-ink: #0B0C0F; /* text/icon ON lime */
--lime-soft:rgba(214,255,62,.12); /* soft fills (chips, round-number badges) */

/* Lines — always low-alpha white, never solid grey */
--line:   rgba(255,255,255,.08);  /* borders, dividers */
--line2:  rgba(255,255,255,.045); /* faint separators, header grid */

/* Status */
--good: #3FD07A;  --good-bg: rgba(63,208,122,.12);
--info: #5B9BFF;  --info-bg: rgba(91,155,255,.14);
--warn: #FF9F45;  --warn-bg: rgba(255,159,69,.12);
--danger: #E5484D;
```

**Route / category colours** (used as accent dots, hero fills, swatches — bright on dark):
```
Green #3FD07A   Orange #FF6A2B   Blue #3E8BFF   Pink #FF4D8D
Yellow #FFC83D  Black #9AA0AC    White #E9E9E2
```

---

## 2. Typography

Two families only. Load from Google Fonts:

```html
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
```

| Role | Font | Rules |
|---|---|---|
| **Display / UI / body** | **Space Grotesk** | Headings **700**, letter-spacing **negative** (−0.8 to −1.6px on big titles). Body 400–500. Buttons/labels 600. |
| **Technical labels & meta** | **Space Mono** | Eyebrows, field labels, chips, stats captions, dates, counts. **UPPERCASE**, letter-spacing **0.1–0.22em**, small (9–11px), colour `--ink3`. This mono-caps treatment is the strongest APEX signal — use it everywhere a label or metadatum appears. |

Scale (px): page title 30–34 · big stat / hero numeral 22–52 · body 14–15 · mono label 9–11.
There is **no italic** and **no serif**. Emphasis = colour (lime) or weight, never slant.

---

## 3. Signature moves (what makes it "APEX")

1. **Mono-caps labels** everywhere (see above). Eyebrow above every title, lime-coloured.
2. **A lime period.** Wordmarks/titles end with a lime `.` — `Beta Board` + lime dot, `Leaderboard.` etc.
3. **Oversized translucent watermark.** A giant numeral/glyph at `rgba(255,255,255,.035)` bleeding off the top-right of headers (the rank `#8`, a climb's grade, a `β`). Pointer-events:none.
4. **Ambient lime glow.** Headers get a soft radial `--lime` glow (~13% alpha) top-right, plus a faint 34px dot/line grid that fades out downward.
5. **Hairline everything.** Borders and dividers are low-alpha white (`--line`), never solid grey. Cards = `--card` fill + 1px `--line`, radius 16.
6. **Lime fills are loud, rare, and dark-texted.** Primary button = solid lime, `--lime-ink` text, faint lime glow shadow. Active pill/tab/toggle = lime. Everything else is ghost (transparent + hairline).
7. **Numbers are the hero.** Big Space-Grotesk-700 numerals for stats/points/grades; mono caption beneath.
8. **One gradient, used once per screen max:** `linear-gradient(135deg, #D6FF3E, #b6e02f)` for the "hero" stat card (e.g. Your ranking).

---

## 4. Component recipes

> Each maps to a component in `prototype/kit.jsx` — open it for the exact, working styles.

- **Button (primary):** bg `--lime`, text `--lime-ink`, weight 600, radius 13, pad 14×18, shadow `0 0 0 1px #D6FF3E, 0 8px 22px rgba(214,255,62,.15)`.
- **Button (ghost):** transparent, 1px `--line`, text `--ink`. Use for secondary/cancel.
- **Card:** `--card` + 1px `--line`, radius 16. On hover (pointer devices) border → `rgba(214,255,62,.5)`.
- **Input / textarea:** `--raise` fill, 1px `--line`, radius 12, `--ink` text; placeholder `--ink3`. Label above in mono-caps `--ink3`. Focus: lime border.
- **Chip / tag:** mono-caps 9.5px, radius 999. Tones: soft (`rgba(255,255,255,.06)`), accent/you (`--lime-soft` + lime text), open (`--good-bg`+good), upcoming/finals (`--info-bg`+info), closed (faint).
- **Grade pill / segmented control:** unselected = `--raise` + `--line` + `--ink2`; selected = `--lime` + `--lime-ink`. Radius 10.
- **Toggle:** off = `rgba(255,255,255,.16)`; on = `--lime` with `--lime-ink` knob.
- **Stat cell:** big Grotesk-700 number + mono-caps caption, separated by 1px `--line2` verticals.
- **Progress bar:** track `--line`; fill `--lime` (or `--ink2` for non-self rows). Height 5–6, radius 999.
- **Avatar:** `--raise` circle, 1px `--line`, Grotesk-600 initials.
- **Header (page scaffold):** glow + grid background, mono-caps eyebrow (lime), Grotesk-700 title (with optional lime word), then content on `--bg` separated by a 1px `--line2` top border. See `PageShell` in `prototype/nav.jsx`.
- **Modal:** `--panel` sheet, 1px `--line`, radius 18, backdrop `rgba(4,5,7,.66)` + blur.

Misc: hide scrollbars; `datetime-local` picker indicator `filter:invert(.6)`; corner radii 10–18; generous 20–24px screen padding.

---

## 5. How to apply (suggested prompt to Claude Code)

> "Read `apex_handoff/README.md`. Restyle our app to match the APEX visual system:
> 1. Add the design tokens (§1) to our theme and the two Google fonts (§2).
> 2. Restyle our shared primitives — buttons, cards, inputs, chips, tabs, toggles,
>    headers — using the recipes in §4. Reference the working versions in
>    `prototype/kit.jsx` and `prototype/nav.jsx` for exact values.
> 3. Apply the signature moves in §3 across screens (mono-caps labels, lime accent,
>    watermark numerals, glow headers, hairline cards).
> Keep our existing components, routing, and data — change only appearance."

To **see** the target, open `prototype/Beta Board App.html` in a browser (the toggle
top-right flips Climber/Setter; state persists). It's a reference, not code to copy —
recreate the look in your own stack.

## Files
```
README.md                  ← this spec (the important part)
prototype/
  kit.jsx                  ← design system: tokens + every styled primitive (START HERE)
  nav.jsx                  ← PageShell header scaffold + top bar
  pages-*.jsx              ← the 14 screens, for reference on how pieces compose
  app.jsx, data.jsx        ← router + mock data (no backend)
  Beta Board App.html      ← open to run the reference prototype
```
