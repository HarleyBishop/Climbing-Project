// pages-auth.jsx — Login, Register, NotFound (full-bleed dark, no PageShell).

function GoogleWord(){
  return <span style={{ fontFamily:"'Space Grotesk', sans-serif", fontWeight:700, fontSize:14 }}>
    <span style={{ color:'#4285F4' }}>G</span><span style={{ color:'#EA4335' }}>o</span><span style={{ color:'#FBBC05' }}>o</span><span style={{ color:'#4285F4' }}>g</span><span style={{ color:'#34A853' }}>l</span><span style={{ color:'#EA4335' }}>e</span>
  </span>;
}

function AuthShell({ children }){
  const P = useP();
  return (
    <div style={{ minHeight:'100%', position:'relative', background:P.bg, display:'flex', flexDirection:'column', padding:'0 24px 30px', overflow:'hidden' }}>
      <Sky />
      {children}
    </div>
  );
}

function Login(){
  const P = useP();
  const r = useRouter();
  return (
    <AuthShell>
      <span style={{ position:'absolute', top:-30, right:-30, fontFamily:P.disp, fontWeight:700, fontSize:300, lineHeight:1, color:'rgba(255,255,255,.035)', pointerEvents:'none', userSelect:'none' }}>β</span>
      <div style={{ position:'relative', paddingTop:56 }}>
        <Eyebrow accent>Bouldering · index</Eyebrow>
        <h1 style={{ fontFamily:P.disp, fontWeight:700, fontSize:52, lineHeight:0.92, letterSpacing:-1.6, margin:'14px 0 0', color:P.ink }}>BETA<br/>BOARD<span style={{ color:P.lime }}>.</span></h1>
        <p style={{ fontFamily:P.mono, fontSize:12.5, color:P.ink2, margin:'18px 0 0', lineHeight:1.55, maxWidth:250 }}>Track every send. Vote the grade. Climb the board.</p>
      </div>
      <div style={{ position:'relative', marginTop:'auto', display:'flex', flexDirection:'column', gap:14 }}>
        <Field label="Username" value="" placeholder="your handle" />
        <Field label="Password" value="••••••••" />
        <Btn full onClick={()=>r.go('home')} style={{ marginTop:4 }}>Log in →</Btn>
        <p style={{ textAlign:'center', margin:'2px 0 0', fontFamily:P.mono, fontSize:11.5, color:P.ink2 }}>
          No account? <span onClick={()=>r.go('register')} style={{ color:P.lime, cursor:'pointer' }}>Create one</span>
        </p>
        <div style={{ display:'flex', alignItems:'center', gap:12, margin:'8px 0 2px' }}>
          <span style={{ flex:1, height:1, background:P.line }} />
          <span style={{ fontFamily:P.mono, fontSize:10, letterSpacing:'0.12em', textTransform:'uppercase', color:P.ink3 }}>or</span>
          <span style={{ flex:1, height:1, background:P.line }} />
        </div>
        <Btn full variant="ghost" onClick={()=>r.go('home')}><GoogleWord/></Btn>
      </div>
    </AuthShell>
  );
}

function Register(){
  const P = useP();
  const r = useRouter();
  const [role,setRole] = React.useState('climber');
  return (
    <AuthShell>
      <div style={{ position:'relative', paddingTop:56 }}>
        <Eyebrow accent>New climber</Eyebrow>
        <h1 style={{ fontFamily:P.disp, fontWeight:700, fontSize:40, lineHeight:0.96, letterSpacing:-1.2, margin:'14px 0 0', color:P.ink }}>Start your<br/>climbing story<span style={{ color:P.lime }}>.</span></h1>
      </div>
      <div style={{ position:'relative', marginTop:'auto', display:'flex', flexDirection:'column', gap:14 }}>
        <Field label="Username" value="" placeholder="pick a handle" />
        <Field label="Password" value="" placeholder="create a password" />
        <div>
          <Eyebrow style={{ marginBottom:9 }}>Registering as a…</Eyebrow>
          <div style={{ display:'flex', gap:10 }}>
            {[['climber','Climber'],['setter','Setter / Owner']].map(([k,lab])=>{
              const sel = role===k;
              return <button key={k} onClick={()=>setRole(k)} style={{ flex:1, fontFamily:P.disp, fontWeight:600, fontSize:13, padding:'11px 8px', borderRadius:11, cursor:'pointer', border:`1px solid ${sel?P.lime:P.line}`, background:sel?P.lime:P.raise, color:sel?P.limeInk:P.ink2, transition:'all .12s' }}>{lab}</button>;
            })}
          </div>
        </div>
        <Btn full onClick={()=>{ r.setRole(role); r.go('login'); }} style={{ marginTop:4 }}>Create account</Btn>
        <p style={{ textAlign:'center', margin:'2px 0 0', fontFamily:P.mono, fontSize:11.5, color:P.ink2 }}>
          Have an account? <span onClick={()=>r.go('login')} style={{ color:P.lime, cursor:'pointer' }}>Log in</span>
        </p>
        <p style={{ textAlign:'center', margin:0, fontFamily:P.mono, fontSize:10.5, color:P.ink3, lineHeight:1.6 }}>
          Google sign-in always creates a Climber account.
        </p>
      </div>
    </AuthShell>
  );
}

function NotFound(){
  const P = useP();
  const r = useRouter();
  return (
    <div style={{ minHeight:'100%', position:'relative', background:P.bg, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', padding:'40px 30px', textAlign:'center', overflow:'hidden' }}>
      <Sky />
      <span style={{ position:'absolute', top:'50%', left:'50%', transform:'translate(-50%,-50%)', fontFamily:P.disp, fontWeight:700, fontSize:240, lineHeight:1, color:'rgba(255,255,255,.04)', pointerEvents:'none' }}>404</span>
      <div style={{ position:'relative' }}>
        <Eyebrow accent style={{ marginBottom:14 }}>Route not found</Eyebrow>
        <h1 style={{ fontFamily:P.disp, fontWeight:700, fontSize:34, letterSpacing:-1, margin:0, color:P.ink }}>Lost the beta?</h1>
        <p style={{ fontFamily:P.mono, fontSize:13, color:P.ink2, margin:'12px 0 26px', lineHeight:1.6 }}>This route doesn’t exist on the wall.</p>
        <Btn onClick={()=>r.go('home')}>Back to your gyms →</Btn>
      </div>
    </div>
  );
}

Object.assign(window, { Login, Register, NotFound });
