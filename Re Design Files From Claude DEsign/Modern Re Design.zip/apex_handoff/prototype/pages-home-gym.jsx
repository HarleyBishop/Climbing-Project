// pages-home-gym.jsx — Home, GymPage, AddClimb, ArchivedClimbs.

function GymRow({ g }){
  const P = useP();
  const r = useRouter();
  const dot = HOLD[g.strip] || P.lime;
  return (
    <Card hover onClick={()=>r.go('gym',{ gymId:g.id })} style={{ padding:'15px 16px', marginBottom:11 }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:10 }}>
        <div style={{ minWidth:0 }}>
          <p style={{ fontFamily:P.disp, fontWeight:600, fontSize:18.5, letterSpacing:-0.3, margin:0, color:P.ink, lineHeight:1.1 }}>{g.name}</p>
          <p style={{ fontFamily:P.mono, fontSize:11, color:P.ink2, margin:'5px 0 0' }}>{g.location.split(',')[0]}</p>
        </div>
        <span style={{ display:'flex', alignItems:'center', gap:6, fontFamily:P.mono, fontSize:9.5, letterSpacing:'0.1em', textTransform:'uppercase', color: g.is_active?P.good:P.ink3, flexShrink:0 }}>
          <span style={{ width:7, height:7, borderRadius:'50%', background:g.is_active?P.good:P.ink3, boxShadow:g.is_active?`0 0 8px ${P.good}`:'none' }} />{g.is_active?'Open':'Closed'}
        </span>
      </div>
      <div style={{ display:'flex', gap:20, alignItems:'center', marginTop:12, paddingTop:12, borderTop:`1px solid ${P.line2}` }}>
        <div><div style={{ fontFamily:P.disp, fontWeight:600, fontSize:21, color:P.ink, lineHeight:1 }}>{g.wall_count}</div><div style={{ fontFamily:P.mono, fontSize:9, letterSpacing:'0.14em', textTransform:'uppercase', color:P.ink3, marginTop:3 }}>Walls</div></div>
        <div><div style={{ fontFamily:P.disp, fontWeight:600, fontSize:21, color:P.ink, lineHeight:1 }}>{g.climb_count}</div><div style={{ fontFamily:P.mono, fontSize:9, letterSpacing:'0.14em', textTransform:'uppercase', color:P.ink3, marginTop:3 }}>Climbs</div></div>
        <span style={{ width:9, height:9, borderRadius:'50%', background:dot, marginLeft:2 }} />
        <span style={{ marginLeft:'auto', fontSize:19, color:P.ink2 }}>→</span>
      </div>
    </Card>
  );
}

function ClimbTile({ c, gymId, setLabel }){
  const P = useP();
  const r = useRouter();
  const hold = HOLD[c.colour];
  return (
    <div>
      {setLabel && <p style={{ fontFamily:P.mono, fontSize:10, letterSpacing:'0.06em', textTransform:'uppercase', color:P.ink3, margin:'0 0 6px' }}>Set {fmtDate(c.set_at)}</p>}
      <Card hover onClick={()=>r.go('climb',{ gymId, climbId:c.id })} style={{ overflow:'hidden' }}>
        <div style={{ position:'relative', height:74, overflow:'hidden' }}>
          <div style={{ position:'absolute', inset:0, background:`linear-gradient(150deg, ${hold} 0%, ${hold} 55%, rgba(0,0,0,.4) 140%)` }} />
          <div style={{ position:'absolute', top:8, right:10, fontFamily:P.disp, fontWeight:700, fontSize:30, lineHeight:1, color:'rgba(11,12,15,.22)' }}>V{c.suggested_grade}</div>
          <span style={{ position:'absolute', bottom:8, left:9, fontFamily:P.mono, fontWeight:700, fontSize:9, letterSpacing:'0.1em', textTransform:'uppercase', padding:'3px 8px', borderRadius:999, background:'rgba(11,12,15,.34)', color:'#fff' }}>{c.colour}</span>
        </div>
        <div style={{ padding:'11px 12px 13px' }}>
          <p style={{ fontFamily:P.disp, fontWeight:600, fontSize:15, letterSpacing:-0.2, margin:0, color:P.ink, lineHeight:1.1, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{c.name}</p>
          <p style={{ fontFamily:P.mono, fontSize:10, color:P.ink2, margin:'5px 0 0' }}>SET V{c.suggested_grade}{c.community_grade?` · COM V${c.community_grade}`:''}</p>
        </div>
      </Card>
    </div>
  );
}

function MapBlock(){
  const P = useP();
  return (
    <div style={{ position:'relative', height:150, borderRadius:16, overflow:'hidden', border:`1px solid ${P.line}`, background:P.card }}>
      <div style={{ position:'absolute', inset:0, backgroundImage:`linear-gradient(${P.line2} 1px, transparent 1px), linear-gradient(90deg, ${P.line2} 1px, transparent 1px)`, backgroundSize:'26px 26px' }} />
      <div style={{ position:'absolute', top:'-30%', left:'30%', width:'70%', height:'120%', background:`radial-gradient(closest-side, ${P.lime}1f, transparent 70%)` }} />
      {[['32%','46%'],['58%','62%'],['46%','32%']].map(([l,t],i)=>(
        <div key={i} style={{ position:'absolute', left:l, top:t, width:14, height:14, borderRadius:'50% 50% 50% 0', background:P.lime, transform:'translate(-50%,-100%) rotate(-45deg)', boxShadow:`0 0 10px ${P.lime}88` }} />
      ))}
      <span style={{ position:'absolute', bottom:9, right:11, fontFamily:P.mono, fontSize:9.5, letterSpacing:'0.08em', textTransform:'uppercase', color:P.ink2, background:'rgba(11,12,15,.5)', padding:'3px 8px', borderRadius:6 }}>interactive map</span>
    </div>
  );
}

function Home(){
  const P = useP();
  const r = useRouter();
  return (
    <PageShell eyebrow="Tue · 07:42" title="Where are you climbing" titleItalic="today?" heroHeight={184}>
      <div style={{ background:P.raise, border:`1px solid ${P.line}`, borderRadius:12, padding:'12px 15px', display:'flex', alignItems:'center', gap:10, marginBottom:22, fontFamily:P.mono, fontSize:13, color:P.ink3 }}>
        <span style={{ color:P.ink2, fontSize:15 }}>⌕</span> search gyms near you…
      </div>
      <SectionLabel right={<span style={{ fontFamily:P.mono, fontSize:10.5, color:P.ink3, letterSpacing:'0.08em' }}>{GYMS.length} SAVED</span>}>Your gyms</SectionLabel>
      {GYMS.map(g=>(<GymRow key={g.id} g={g} />))}
      <Divider m={24} />
      <SectionLabel>Gyms near you</SectionLabel>
      <MapBlock />
      {r.role==='setter' && <Btn full onClick={()=>r.go('createGym')} style={{ marginTop:24 }}>+ Create a gym</Btn>}
    </PageShell>
  );
}

function ghostPill(P){ return { fontFamily:P.mono, fontWeight:400, fontSize:10.5, letterSpacing:'0.08em', textTransform:'uppercase', padding:'7px 13px', borderRadius:999, cursor:'pointer', border:`1px solid ${P.line}`, background:'rgba(255,255,255,.04)', color:P.ink }; }

function GymPage({ params }){
  const P = useP();
  const r = useRouter();
  const gym = GYMS.find(g=>g.id===(params.gymId||1)) || GYMS[0];
  const [wall,setWall] = React.useState(WALLS[0]);
  const [confirm,setConfirm] = React.useState(false);
  const climbs = CLIMBS;
  const headerRight = (
    <div style={{ marginTop:16, display:'flex', alignItems:'center', gap:8, flexWrap:'wrap' }}>
      <Chip tone={gym.is_active?'open':'closed'}>{gym.is_active?'Open':'Closed'}</Chip>
      <div style={{ flex:1 }} />
      <button onClick={()=>r.go('comps',{ gymId:gym.id })} style={ghostPill(P)}>Competitions</button>
      <button onClick={()=>r.go('leaderboard',{ gymId:gym.id })} style={ghostPill(P)}>Leaderboard</button>
    </div>
  );
  return (
    <PageShell back backLabel="Your gyms" onBack={()=>r.go('home')} eyebrow={gym.location} title={gym.name} right={headerRight} heroHeight={176}>
      <SectionLabel>Select wall</SectionLabel>
      <div style={{ display:'flex', gap:8, flexWrap:'wrap', marginBottom:22 }}>
        {WALLS.map(w=>{
          const sel = wall.id===w.id;
          return <button key={w.id} onClick={()=>{ setWall(w); setConfirm(false); }} style={{ fontFamily:P.disp, fontWeight:600, fontSize:13, padding:'8px 15px', borderRadius:999, cursor:'pointer', border:`1px solid ${sel?P.lime:P.line}`, background:sel?P.lime:P.raise, color:sel?P.limeInk:P.ink2, transition:'all .12s' }}>{w.name}</button>;
        })}
      </div>
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:14, gap:10 }}>
        <div style={{ display:'flex', alignItems:'center', gap:12, minWidth:0 }}>
          <Eyebrow accent>{wall.name} · {climbs.length}</Eyebrow>
          <button onClick={()=>r.go('archived',{ gymId:gym.id, wall:wall.name })} style={{ background:'none', border:'none', cursor:'pointer', fontFamily:P.mono, fontSize:10.5, letterSpacing:'0.06em', textTransform:'uppercase', color:P.ink3, padding:0, whiteSpace:'nowrap' }}>Archived</button>
        </div>
        {r.role==='setter' && <Btn size="sm" onClick={()=>r.go('addClimb',{ gymId:gym.id, wall:wall.name })}>+ Add</Btn>}
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:13 }}>
        {climbs.map(c=>(<ClimbTile key={c.id} c={c} gymId={gym.id} />))}
      </div>
      {r.role==='setter' && (
        <div style={{ marginTop:18 }}>
          {confirm ? (
            <Card style={{ display:'flex', alignItems:'center', gap:10, padding:'13px 15px', borderColor:'#E5484D' }}>
              <p style={{ flex:1, fontFamily:P.mono, fontSize:11.5, color:P.ink, margin:0, lineHeight:1.5 }}>Archive all {climbs.length} climbs on {wall.name}?</p>
              <Btn size="sm" variant="danger" onClick={()=>setConfirm(false)}>Archive</Btn>
              <Btn size="sm" variant="ghost" onClick={()=>setConfirm(false)}>Cancel</Btn>
            </Card>
          ) : (
            <button onClick={()=>setConfirm(true)} style={{ background:'none', border:'none', cursor:'pointer', fontFamily:P.mono, fontSize:10.5, letterSpacing:'0.06em', textTransform:'uppercase', color:P.ink3, padding:0 }}>Archive all climbs on this wall</button>
          )}
        </div>
      )}
    </PageShell>
  );
}

function AddClimb({ params }){
  const P = useP();
  const r = useRouter();
  const [colour,setColour] = React.useState('Orange');
  const [grade,setGrade] = React.useState(5);
  return (
    <PageShell back backLabel="Back to gym" onBack={()=>r.go('gym',{ gymId:params.gymId })} eyebrow={params.wall||'Crimp Wall'} title="Add a new climb">
      <div style={{ display:'flex', flexDirection:'column', gap:22 }}>
        <Field label="Climb name" value="" placeholder="e.g. Crimpy arête" />
        <div>
          <Eyebrow style={{ marginBottom:11 }}>Hold colour — <span style={{ color:P.lime }}>{colour}</span></Eyebrow>
          <ColourSwatches value={colour} onPick={setColour} />
        </div>
        <div>
          <Eyebrow style={{ marginBottom:11 }}>Setter grade — V{grade}</Eyebrow>
          <GradePills grades={[0,1,2,3,4,5,6,7,8,9,10,11,12]} value={grade} onPick={setGrade} />
        </div>
        <div>
          <Eyebrow style={{ marginBottom:9 }}>Photo · optional</Eyebrow>
          <div style={{ height:120, borderRadius:12, border:`1.5px dashed ${P.line}`, background:P.raise, display:'flex', alignItems:'center', justifyContent:'center' }}>
            <span style={{ fontFamily:P.mono, fontSize:11, letterSpacing:'0.06em', textTransform:'uppercase', color:P.ink3 }}>drop a wall photo</span>
          </div>
        </div>
        <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
          <Btn full onClick={()=>r.go('gym',{ gymId:params.gymId })}>Add climb</Btn>
          <Btn full variant="ghost" onClick={()=>r.go('gym',{ gymId:params.gymId })}>Cancel</Btn>
        </div>
      </div>
    </PageShell>
  );
}

function ArchivedClimbs({ params }){
  const P = useP();
  const r = useRouter();
  const archived = CLIMBS.slice(0,4);
  return (
    <PageShell back backLabel="Back to gym" onBack={()=>r.go('gym',{ gymId:params.gymId })} eyebrow={`${params.wall||'Crimp Wall'} · old routes`} title="Archived climbs">
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:13 }}>
        {archived.map(c=>(<ClimbTile key={c.id} c={c} gymId={params.gymId} setLabel />))}
      </div>
    </PageShell>
  );
}

Object.assign(window, { Home, GymPage, AddClimb, ArchivedClimbs, GymRow, ClimbTile, MapBlock });
