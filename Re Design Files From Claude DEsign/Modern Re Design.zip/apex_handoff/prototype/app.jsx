// app.jsx — router provider, mobile frame, screen switch. Single APEX theme.

const SCREENS = {
  login: ()=> <Login/>,
  register: ()=> <Register/>,
  home: (p)=> <Home params={p}/>,
  gym: (p)=> <GymPage params={p}/>,
  climb: (p)=> <ClimbPage params={p}/>,
  profile: (p)=> <Profile params={p}/>,
  leaderboard: (p)=> <Leaderboard params={p}/>,
  comps: (p)=> <CompetitionList params={p}/>,
  comp: (p)=> <CompetitionPage params={p}/>,
  createGym: (p)=> <CreateGym params={p}/>,
  addClimb: (p)=> <AddClimb params={p}/>,
  archived: (p)=> <ArchivedClimbs params={p}/>,
  createComp: (p)=> <CreateCompetition params={p}/>,
  notFound: ()=> <NotFound/>,
};

const LS = 'betaboard-apex';
function loadState(){ try { return JSON.parse(localStorage.getItem(LS)) || {}; } catch { return {}; } }

function Root(){
  const saved = loadState();
  const [role,setRoleRaw] = React.useState(saved.role || 'setter');
  const [view,setView] = React.useState(saved.view || { screen:'login', params:{} });
  const stack = React.useRef([]);
  const frameRef = React.useRef(null);

  const persist = (patch)=>{ try { localStorage.setItem(LS, JSON.stringify({ role, view, ...patch })); } catch {} };
  const setRole = (k)=>{ setRoleRaw(k); persist({ role:k }); };
  const go = (screen, params={})=>{
    stack.current.push(view);
    const v = { screen, params }; setView(v); persist({ view:v });
    if(frameRef.current) frameRef.current.scrollTop = 0;
  };
  const back = ()=>{
    const prev = stack.current.pop();
    const v = prev || { screen:'home', params:{} }; setView(v); persist({ view:v });
    if(frameRef.current) frameRef.current.scrollTop = 0;
  };

  const router = { ...view, go, back, role, setRole };
  const render = SCREENS[view.screen] || SCREENS.notFound;

  return (
    <ThemeCtx.Provider value={APEX}>
      <RouterCtx.Provider value={router}>
        <div style={{ minHeight:'100vh', width:'100%', background:APEX.page, display:'flex', justifyContent:'center' }}>
          <div ref={frameRef} style={{ position:'relative', width:'100%', maxWidth:432, height:'100vh', overflowY:'auto', overflowX:'hidden', background:APEX.bg, boxShadow:'0 0 80px rgba(0,0,0,.5)' }}>
            {render(view.params)}
          </div>
        </div>
        <FloatingControls/>
      </RouterCtx.Provider>
    </ThemeCtx.Provider>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<Root/>);
