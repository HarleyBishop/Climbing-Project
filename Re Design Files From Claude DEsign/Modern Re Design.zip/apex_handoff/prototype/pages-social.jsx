// pages-social.jsx — Profile & Leaderboard.

function StatTile({ v, l }){
  const P = useP();
  return (
    <div style={{ background:P.card, border:`1px solid ${P.line}`, borderRadius:13, padding:'13px 6px', textAlign:'center' }}>
      <p style={{ fontFamily:P.disp, fontWeight:600, fontSize:22, margin:0, color:P.ink, lineHeight:1 }}>{v}</p>
      <p style={{ fontFamily:P.mono, fontSize:9, letterSpacing:'0.08em', textTransform:'uppercase', color:P.ink3, margin:'6px 0 0' }}>{l}</p>
    </div>
  );
}

function Profile(){
  const P = useP();
  const r = useRouter();
  const rank = getRank(ME.points);
  const avg = Math.round(ME.sends.reduce((s,x)=>s+x.climb_grade,0)/ME.sends.length);
  const headerRight = (
    <div style={{ display:'flex', alignItems:'center', gap:10, marginTop:14, flexWrap:'wrap' }}>
      <RankBadge rank={rank} />
      <span style={{ fontFamily:P.disp, fontWeight:600, fontSize:14, color:P.ink }}>{ME.points.toLocaleString()} pts</span>
      <span style={{ fontFamily:P.mono, fontSize:10.5, color:P.ink3 }}>· since Aug 2024</span>
    </div>
  );
  return (
    <PageShell back backLabel="Home" onBack={()=>r.go('home')} eyebrow="Your profile" title={`@${ME.username}`} right={headerRight} heroHeight={178} watermark="β">
      <Card style={{ display:'flex', alignItems:'center', gap:12, padding:'14px 15px', marginBottom:20 }}>
        <span style={{ width:9, height:9, borderRadius:'50%', background:P.accent, flexShrink:0 }} />
        <div>
          <Eyebrow style={{ marginBottom:4 }}>Home gym</Eyebrow>
          <p style={{ fontFamily:P.disp, fontWeight:600, fontSize:16, letterSpacing:-0.2, margin:0, color:P.ink }}>{ME.home_gym}</p>
        </div>
      </Card>

      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:10, marginBottom:24 }}>
        <StatTile v={ME.sends.length} l="Sends" />
        <StatTile v={ME.reviews.length} l="Reviews" />
        <StatTile v={ME.videos} l="Videos" />
        <StatTile v={`V${avg}`} l="Avg" />
      </div>

      <SectionLabel>Sends · {ME.sends.length}</SectionLabel>
      <div style={{ display:'flex', flexDirection:'column', gap:10, marginBottom:24 }}>
        {ME.sends.map(s=>(
          <Card key={s.id} hover onClick={()=>r.go('climb',{ gymId:1, climbId:s.id })} style={{ display:'flex', overflow:'hidden', alignItems:'stretch' }}>
            <div style={{ width:5, background:HOLD[s.climb_colour], flexShrink:0 }} />
            <div style={{ flex:1, padding:'12px 14px', minWidth:0 }}>
              <p style={{ fontFamily:P.disp, fontWeight:600, fontSize:15.5, letterSpacing:-0.2, margin:0, color:P.ink, lineHeight:1.1 }}>{s.climb_name}</p>
              <p style={{ fontFamily:P.mono, fontSize:10.5, color:P.ink2, margin:'4px 0 0' }}>{s.wall_name} · {s.gym_name}</p>
            </div>
            <div style={{ display:'flex', flexDirection:'column', alignItems:'flex-end', justifyContent:'center', gap:5, padding:'0 14px' }}>
              <Chip tone="accent">V{s.climb_grade}</Chip>
              <span style={{ fontFamily:P.mono, fontSize:10, color:P.ink3 }}>{s.attempts} ATT.</span>
            </div>
          </Card>
        ))}
      </div>

      <SectionLabel>Reviews · {ME.reviews.length}</SectionLabel>
      <div style={{ display:'flex', flexDirection:'column', gap:12, marginBottom:24 }}>
        {ME.reviews.map(rv=>(
          <Card key={rv.id} style={{ padding:'14px 15px' }}>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:9 }}>
              <p style={{ fontFamily:P.disp, fontWeight:600, fontSize:15.5, letterSpacing:-0.2, margin:0, color:P.ink }}>{rv.climb_name}</p>
              <Stars n={rv.stars} />
            </div>
            <p style={{ fontFamily:P.disp, fontWeight:500, fontSize:14, lineHeight:1.45, color:P.ink2, margin:'0 0 8px' }}><span style={{ color:P.lime }}>“</span>{rv.comment}<span style={{ color:P.lime }}>”</span></p>
            <p style={{ fontFamily:P.mono, fontSize:10.5, color:P.ink3, margin:0 }}>{rv.wall_name} · {rv.gym_name}</p>
          </Card>
        ))}
      </div>

      <SectionLabel>Videos · {ME.videos}</SectionLabel>
      <div style={{ display:'flex', gap:11 }}>
        {[0,1].map(i=>(
          <div key={i} style={{ flex:1, position:'relative', height:92, borderRadius:12, overflow:'hidden', border:`1px solid ${P.line}`, background:`linear-gradient(150deg, ${HOLD.Blue}, rgba(0,0,0,.5))` }}>
            <div style={{ position:'absolute', top:'50%', left:'50%', transform:'translate(-50%,-50%)', width:32, height:32, borderRadius:'50%', background:'rgba(11,12,15,.55)', border:'1px solid rgba(255,255,255,.4)', display:'flex', alignItems:'center', justifyContent:'center' }}>
              <span style={{ marginLeft:3, borderStyle:'solid', borderWidth:'6px 0 6px 10px', borderColor:'transparent transparent transparent #fff' }} />
            </div>
          </div>
        ))}
      </div>
    </PageShell>
  );
}

function rankColour(P, n){ return n===1?P.lime : n<=3?P.ink : P.ink2; }

function Leaderboard({ params }){
  const P = useP();
  const r = useRouter();
  const gym = GYMS.find(g=>g.id===(params.gymId||1)) || GYMS[0];
  const me = LEADERBOARD.find(e=>e.username==='you');
  const maxPts = LEADERBOARD[0].points;
  return (
    <PageShell back backLabel={gym.name} onBack={()=>r.go('gym',{ gymId:gym.id })} eyebrow={`${gym.name} · ${gym.climb_count} active climbs`} title="Leaderboard" watermark={`#${me.rank}`}>
      <div style={{ background:`linear-gradient(135deg, ${P.lime} 0%, ${P.limeD} 100%)`, borderRadius:18, padding:'18px 20px', color:P.limeInk, position:'relative', overflow:'hidden', marginBottom:24 }}>
        <div style={{ position:'absolute', top:-20, right:-8, fontFamily:P.disp, fontWeight:700, fontSize:120, lineHeight:1, opacity:.16 }}>#{me.rank}</div>
        <div style={{ position:'relative' }}>
          <p style={{ fontFamily:P.mono, fontSize:10, letterSpacing:'0.16em', textTransform:'uppercase', opacity:.7, margin:0 }}>Your ranking</p>
          <div style={{ display:'flex', alignItems:'baseline', gap:10, marginTop:7 }}>
            <span style={{ fontFamily:P.disp, fontWeight:700, fontSize:40, letterSpacing:-1.2, lineHeight:1 }}>{me.points.toLocaleString()}</span>
            <span style={{ fontFamily:P.mono, fontSize:12 }}>pts · {me.send_count} sends</span>
          </div>
        </div>
      </div>

      <SectionLabel>Top climbers</SectionLabel>
      <div style={{ display:'flex', flexDirection:'column', gap:9, marginBottom:24 }}>
        {LEADERBOARD.map(e=>{
          const isMe = e.username==='you';
          const rk = getRank(e.points, e.rank);
          const bar = Math.round((e.points/maxPts)*100);
          return (
            <Card key={e.user_id} hover onClick={()=>r.go('profile')} style={{ display:'flex', alignItems:'center', gap:12, padding:'12px 14px', border:isMe?`1px solid rgba(214,255,62,.5)`:undefined }}>
              <span style={{ fontFamily:P.mono, fontWeight:700, fontSize:13, color:rankColour(P,e.rank), minWidth:24, textAlign:'center' }}>{String(e.rank).padStart(2,'0')}</span>
              <Avatar name={e.username} size={32} />
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ display:'flex', alignItems:'center', gap:7, marginBottom:7 }}>
                  <span style={{ fontFamily:P.disp, fontWeight:600, fontSize:14, color:P.ink, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>@{e.username}</span>
                  {isMe && <Chip tone="you">You</Chip>}
                </div>
                <div style={{ height:5, background:P.line, borderRadius:999, overflow:'hidden' }}>
                  <div style={{ height:'100%', width:`${bar}%`, background:isMe?P.lime:P.ink2, borderRadius:999 }} />
                </div>
              </div>
              <div style={{ display:'flex', flexDirection:'column', alignItems:'flex-end', gap:5 }}>
                <RankBadge rank={rk} showName={false} iconSize={15} />
                <span style={{ fontFamily:P.disp, fontWeight:600, fontSize:12.5, color:P.ink }}>{e.points.toLocaleString()}</span>
              </div>
            </Card>
          );
        })}
      </div>

      <SectionLabel>Rank tiers</SectionLabel>
      <Card style={{ overflow:'hidden', marginBottom:24 }}>
        {RANKS.map((rk,i)=>(
          <div key={rk.name} style={{ display:'flex', alignItems:'center', gap:11, padding:'10px 14px', borderTop:i?`1px solid ${P.line2}`:'none' }}>
            <div style={{ width:108 }}><RankBadge rank={rk} /></div>
            <div style={{ flex:1, height:5, background:P.line, borderRadius:999, overflow:'hidden' }}>
              <div style={{ height:'100%', width:`${Math.max(4,Math.round((rk.min/4500)*100))}%`, background:rk.color, borderRadius:999 }} />
            </div>
            <span style={{ fontFamily:P.mono, fontSize:10, color:P.ink3, width:54, textAlign:'right' }}>{rk.min===0?'0':`${rk.min.toLocaleString()}+`}</span>
          </div>
        ))}
        <div style={{ display:'flex', alignItems:'center', gap:11, padding:'10px 14px', borderTop:`1px solid ${P.line2}` }}>
          <div style={{ width:108 }}><RankBadge rank={MAGNUS_RANK} /></div>
          <p style={{ flex:1, fontFamily:P.mono, fontSize:10.5, color:P.ink3, margin:0 }}>Top 20 at this gym</p>
        </div>
      </Card>

      <SectionLabel>Points per grade</SectionLabel>
      <Card style={{ overflow:'hidden' }}>
        {GRADE_POINTS.map((t,i)=>(
          <div key={i} style={{ display:'flex', alignItems:'center', gap:12, padding:'11px 14px', borderTop:i?`1px solid ${P.line2}`:'none' }}>
            <span style={{ fontFamily:P.mono, fontSize:11, color:P.ink2, width:64 }}>{t.label}</span>
            <div style={{ flex:1, height:6, background:P.line, borderRadius:999, overflow:'hidden' }}>
              <div style={{ height:'100%', width:`${Math.round((t.points/150)*100)}%`, background:P.lime, borderRadius:999 }} />
            </div>
            <span style={{ fontFamily:P.disp, fontWeight:600, fontSize:12.5, color:P.ink, width:52, textAlign:'right' }}>{t.points} pts</span>
          </div>
        ))}
      </Card>
    </PageShell>
  );
}

Object.assign(window, { Profile, Leaderboard, rankColour });
