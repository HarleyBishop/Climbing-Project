// nav.jsx — router context, APEX top bar, PageShell scaffold (glow header +
// content), and the floating role toggle (Climber ⇄ Setter). Single theme.

const RouterCtx = React.createContext(null);
const useRouter = () => React.useContext(RouterCtx);

function TopBar({ back, backLabel, onBack }){
  const P = useP();
  const r = useRouter();
  return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', minHeight:34 }}>
      {back ? (
        <button onClick={onBack || (()=>r.back())} style={{ background:'none', border:'none', cursor:'pointer', padding:0, fontFamily:P.mono, fontWeight:400, fontSize:12, letterSpacing:'0.08em', textTransform:'uppercase', color:P.ink2, display:'inline-flex', alignItems:'center', gap:6, maxWidth:210, overflow:'hidden', whiteSpace:'nowrap', textOverflow:'ellipsis' }}>
          <span style={{ fontSize:15, lineHeight:1 }}>←</span> {backLabel || 'Back'}
        </button>
      ) : (
        <span style={{ fontFamily:P.disp, fontWeight:700, fontSize:18, letterSpacing:-0.3, color:P.ink, whiteSpace:'nowrap' }}>Beta Board<span style={{ color:P.lime }}>.</span></span>
      )}
      <div style={{ display:'flex', alignItems:'center', gap:10 }}>
        {r.role==='setter' && <Chip tone="accent">Setter</Chip>}
        <Avatar name={ME.username} size={32} onClick={()=>r.go('profile')} />
        <button onClick={()=>r.go('login')} style={{ background:'none', border:'none', cursor:'pointer', padding:0, fontFamily:P.mono, fontSize:10.5, letterSpacing:'0.1em', textTransform:'uppercase', color:P.ink3 }}>Exit</button>
      </div>
    </div>
  );
}

function PageShell({ back, backLabel, onBack, eyebrow, title, titleItalic, right, stars, heroHeight=150, watermark, children }){
  const P = useP();
  return (
    <div style={{ minHeight:'100%', background:P.bg, position:'relative' }}>
      <div style={{ position:'relative', minHeight:heroHeight, overflow:'hidden' }}>
        <Sky stars={stars} />
        {watermark && <Watermark>{watermark}</Watermark>}
        <div style={{ position:'relative', padding:'16px 20px 0' }}>
          <TopBar back={back} backLabel={backLabel} onBack={onBack} />
          <div style={{ marginTop:18, paddingBottom:22 }}>
            {eyebrow && <Eyebrow accent style={{ marginBottom:9 }}>{eyebrow}</Eyebrow>}
            {title && (
              <h1 style={{ fontFamily:P.disp, fontWeight:700, fontSize:30, lineHeight:1.0, letterSpacing:-0.8, margin:0, color:P.ink }}>
                {title}{titleItalic && <> <span style={{ color:P.lime }}>{titleItalic}</span></>}
              </h1>
            )}
            {right}
          </div>
        </div>
      </div>
      <div style={{ position:'relative', background:P.bg, borderTop:`1px solid ${P.line2}`, padding:'22px 20px 44px', minHeight:200 }}>
        {children}
      </div>
    </div>
  );
}

function SectionLabel({ children, right, style }){
  return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', gap:10, margin:'0 0 13px', ...style }}>
      <Eyebrow accent>{children}</Eyebrow>
      {right}
    </div>
  );
}
function Empty({ children }){
  const P = useP();
  return <p style={{ fontFamily:P.mono, fontSize:13, color:P.ink3, textAlign:'center', padding:'28px 0', lineHeight:1.6 }}>{children}</p>;
}

// ── floating prototype controls (chrome — not part of the app UI) ──
function FloatingControls(){
  const r = useRouter();
  const seg = (active)=>({ fontFamily:"'Space Grotesk', sans-serif", fontWeight:600, fontSize:11.5, padding:'5px 12px', borderRadius:999, cursor:'pointer', border:'none', background:active?'#D6FF3E':'transparent', color:active?'#0B0C0F':'#8B919C', transition:'all .15s', letterSpacing:0.2 });
  return (
    <div style={{ position:'fixed', top:14, right:14, zIndex:200 }} data-omelette-chrome="">
      <div style={{ display:'flex', gap:3, background:'rgba(16,18,23,.92)', border:'1px solid rgba(255,255,255,.1)', borderRadius:999, padding:3, boxShadow:'0 4px 16px rgba(0,0,0,.4)', backdropFilter:'blur(8px)' }}>
        <button style={seg(r.role==='climber')} onClick={()=>r.setRole('climber')}>Climber</button>
        <button style={seg(r.role==='setter')} onClick={()=>r.setRole('setter')}>Setter</button>
      </div>
    </div>
  );
}

Object.assign(window, { RouterCtx, useRouter, TopBar, PageShell, SectionLabel, Empty, FloatingControls });
