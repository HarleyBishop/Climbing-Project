// kit.jsx — Beta Board · APEX design system (super-modern, single dark theme).
// Near-black canvas, electric-lime accent, Space Grotesk (display/body) + Space
// Mono (technical labels), hairline rules, oversized numerals, lime glow.
// All components read the palette from ThemeCtx via useP().

const FONTS = {
  disp:"'Space Grotesk', system-ui, sans-serif",
  body:"'Space Grotesk', system-ui, sans-serif",
  mono:"'Space Mono', ui-monospace, monospace",
};

const APEX = {
  ...FONTS, key:'apex', label:'Apex',
  ink:'#F5F6F3', ink2:'#8B919C', ink3:'#5A5F69',
  lime:'#D6FF3E', limeInk:'#0B0C0F', limeD:'#b6e02f',
  primary:'#D6FF3E', primaryD:'#b6e02f', primarySoft:'rgba(214,255,62,.12)',
  accent:'#5B9BFF',
  page:'#070809', bg:'#0B0C0F', sheet:'#0B0C0F', panel:'#101217',
  card:'#16181E', raise:'#1C1F26',
  line:'rgba(255,255,255,.08)', line2:'rgba(255,255,255,.045)', lineSoft:'rgba(255,255,255,.08)',
  skyText:'#F5F6F3',
  good:'#3FD07A', goodBg:'rgba(63,208,122,.12)',
  warn:'#FF9F45', warnBg:'rgba(255,159,69,.12)',
  info:'#5B9BFF', infoBg:'rgba(91,155,255,.14)',
};
const THEMES = { apex:APEX };
const ThemeCtx = React.createContext(APEX);
const useP = () => React.useContext(ThemeCtx);

// hold colours (route colours) — vivid on dark
const HOLD = { Green:'#3FD07A', Orange:'#FF6A2B', Blue:'#3E8BFF', Pink:'#FF4D8D', Yellow:'#FFC83D', Black:'#9AA0AC', White:'#E9E9E2' };

// ── rank system ──
const RANKS = [
  { name:'Iron', min:0, color:'#9AA0AC', bg:'#757575' },
  { name:'Bronze', min:100, color:'#D6975B', bg:'#A0522D' },
  { name:'Silver', min:300, color:'#B6C4CC', bg:'#546E7A' },
  { name:'Gold', min:700, color:'#E8C24A', bg:'#B8860B' },
  { name:'Platinum', min:1200, color:'#37D6E0', bg:'#00838F' },
  { name:'Diamond', min:2000, color:'#8E9BF0', bg:'#3949AB' },
  { name:'Emerald', min:3000, color:'#5CD06A', bg:'#2E7D32' },
  { name:'Masters', min:4500, color:'#C98FE0', bg:'#7B1FA2' },
];
const MAGNUS_RANK = { name:'Magnus', color:'#FF6B6B', bg:'#C62828' };
function getRank(points, position=null){
  if(position!==null && position<=20) return MAGNUS_RANK;
  for(let i=RANKS.length-1;i>=0;i--){ if(points>=RANKS[i].min) return RANKS[i]; }
  return RANKS[0];
}
const GRADE_POINTS = [
  { label:'V0–V2', points:10 }, { label:'V3–V4', points:20 }, { label:'V5–V6', points:40 },
  { label:'V7–V8', points:70 }, { label:'V9–V10', points:100 }, { label:'V11–V12+', points:150 },
];
const R = (x,y,w,h,f)=> <rect key={x+'-'+y+'-'+w+'-'+h+'-'+f} x={x} y={y} width={w} height={h} fill={f}/>;
function RankIcon({ name, size=18 }){
  const p = { width:size, height:size, viewBox:'0 0 16 16', shapeRendering:'crispEdges', xmlns:'http://www.w3.org/2000/svg' };
  switch(name){
    case 'Iron': return <svg {...p}>{R(4,1,8,2,'#9AA0AC')}{R(2,3,2,10,'#9AA0AC')}{R(4,13,8,2,'#9AA0AC')}{R(12,3,2,3,'#9AA0AC')}{R(12,10,2,3,'#9AA0AC')}{R(12,6,2,4,'#CDD2DA')}</svg>;
    case 'Bronze': return <svg {...p}>{R(5,1,2,2,'#A0522D')}{R(9,1,2,2,'#A0522D')}{R(4,3,8,2,'#CD853F')}{R(3,5,10,7,'#A0522D')}{R(4,12,8,2,'#A0522D')}{R(5,14,6,1,'#A0522D')}{R(5,3,2,1,'#F5DEB3')}{R(9,3,2,1,'#F5DEB3')}</svg>;
    case 'Silver': return <svg {...p}>{R(2,2,5,5,'#78909C')}{R(3,2,3,3,'#B0BEC5')}{R(1,7,11,3,'#78909C')}{R(2,10,7,2,'#546E7A')}{R(9,9,5,3,'#546E7A')}{R(13,8,2,3,'#546E7A')}{R(2,12,9,2,'#546E7A')}</svg>;
    case 'Gold': return <svg {...p}>{R(3,3,10,9,'#B8860B')}{R(4,4,3,7,'#FFF9C4')}{R(9,4,3,7,'#FFF9C4')}{R(6,12,4,2,'#B8860B')}{R(5,1,6,2,'#DAA520')}{R(4,2,1,1,'#DAA520')}{R(11,2,1,1,'#DAA520')}</svg>;
    case 'Platinum': return <svg {...p}>{R(5,1,6,2,'#00838F')}{R(3,3,2,4,'#00838F')}{R(11,3,2,4,'#00838F')}{R(5,7,6,2,'#00838F')}{R(4,3,8,4,'#00838F')}{R(5,4,6,2,'#E0F7FA')}{R(4,9,8,2,'#00838F')}{R(2,11,2,3,'#00838F')}{R(12,11,2,3,'#00838F')}{R(4,14,8,1,'#00838F')}{R(4,11,8,3,'#00838F')}{R(5,11,6,2,'#E0F7FA')}</svg>;
    case 'Diamond': return <svg {...p}>{R(5,1,6,2,'#3949AB')}{R(3,3,10,2,'#3949AB')}{R(2,5,12,2,'#7986CB')}{R(3,7,10,2,'#3949AB')}{R(4,9,8,2,'#3949AB')}{R(5,11,6,2,'#283593')}{R(6,13,4,2,'#283593')}{R(7,15,2,1,'#283593')}{R(4,3,3,2,'#7986CB')}{R(9,3,3,2,'#7986CB')}</svg>;
    case 'Emerald': return <svg {...p}>{R(4,1,8,2,'#2E7D32')}{R(2,3,12,8,'#2E7D32')}{R(4,11,8,2,'#2E7D32')}{R(5,3,6,6,'#A5D6A7')}{R(3,5,2,4,'#66BB6A')}{R(11,5,2,4,'#1B5E20')}{R(5,9,6,2,'#66BB6A')}</svg>;
    case 'Masters': return <svg {...p}>{R(1,4,2,8,'#7B1FA2')}{R(7,2,2,8,'#7B1FA2')}{R(13,4,2,8,'#7B1FA2')}{R(3,6,4,6,'#7B1FA2')}{R(9,6,4,6,'#7B1FA2')}{R(1,10,14,4,'#6A1B9A')}{R(1,11,14,2,'#7B1FA2')}{R(2,12,2,2,'#CE93D8')}{R(7,12,2,2,'#CE93D8')}{R(12,12,2,2,'#CE93D8')}</svg>;
    case 'Magnus': return <svg {...p}>{R(8,1,1,5,'#FFD54F')}{R(9,1,3,3,'#FFD54F')}{R(7,4,3,2,'#FFCDD2')}{R(5,6,7,2,'#C62828')}{R(5,6,7,1,'#FFCDD2')}{R(3,8,11,2,'#C62828')}{R(1,10,14,5,'#C62828')}{R(4,10,2,3,'#B71C1C')}{R(10,10,2,3,'#B71C1C')}</svg>;
    default: return null;
  }
}
function RankBadge({ rank, showName=true, iconSize=16 }){
  return (
    <span style={{ display:'inline-flex', alignItems:'center', gap:6, padding:'3px 9px', borderRadius:7, background:'rgba(255,255,255,.05)', border:'1px solid rgba(255,255,255,.08)' }}>
      <RankIcon name={rank.name} size={iconSize}/>
      {showName && <span style={{ fontFamily:FONTS.mono, fontSize:10.5, fontWeight:700, letterSpacing:'0.06em', textTransform:'uppercase', color:rank.color }}>{rank.name}</span>}
    </span>
  );
}

// ── date helpers (en-AU) ──
function fmtDate(iso){ try { return new Date(iso).toLocaleDateString('en-AU',{ day:'numeric', month:'short' }); } catch { return iso; } }
function fmtDateLong(iso){ try { return new Date(iso).toLocaleDateString('en-AU',{ day:'numeric', month:'short', year:'numeric' }); } catch { return iso; } }

// ── ambient header glow (replaces ghibli "Sky") ──
function Sky({ glow=true, grid=true, stars }){
  const P = useP();
  return (
    <div style={{ position:'absolute', inset:0, overflow:'hidden', background:P.bg }}>
      {grid && <div style={{ position:'absolute', inset:0, backgroundImage:`linear-gradient(${P.line2} 1px, transparent 1px), linear-gradient(90deg, ${P.line2} 1px, transparent 1px)`, backgroundSize:'34px 34px', opacity:.7, maskImage:'linear-gradient(180deg, #000 0%, transparent 92%)', WebkitMaskImage:'linear-gradient(180deg, #000 0%, transparent 92%)' }} />}
      {glow && <div style={{ position:'absolute', top:'-40%', right:'-10%', width:'80%', height:'160%', background:`radial-gradient(closest-side, ${P.lime}22, transparent 70%)`, pointerEvents:'none' }} />}
    </div>
  );
}
// giant translucent watermark for headers
function Watermark({ children }){
  const P = useP();
  return <span style={{ position:'absolute', top:-22, right:-6, fontFamily:P.disp, fontWeight:700, fontSize:150, lineHeight:1, letterSpacing:-4, color:'rgba(255,255,255,.035)', pointerEvents:'none', userSelect:'none', whiteSpace:'nowrap' }}>{children}</span>;
}

// ── primitives ──
function Eyebrow({ children, color, accent, style }){
  const P = useP();
  return <p style={{ fontFamily:P.mono, fontWeight:400, fontSize:10.5, letterSpacing:'0.2em', textTransform:'uppercase', color:color||(accent?P.lime:P.ink3), margin:0, ...style }}>{children}</p>;
}
function Btn({ children, onClick, full, variant='solid', size='md', style, disabled }){
  const P = useP();
  const pad = size==='sm'?'9px 15px':'14px 18px';
  const fs = size==='sm'?13:15;
  const base = { fontFamily:P.disp, fontWeight:600, fontSize:fs, letterSpacing:0.2, padding:pad, borderRadius:size==='sm'?10:13, cursor:disabled?'default':'pointer', width:full?'100%':'auto', whiteSpace:'nowrap', display:'inline-flex', alignItems:'center', justifyContent:'center', gap:7, opacity:disabled?.45:1, transition:'all .14s', boxSizing:'border-box' };
  const variants = {
    solid:{ color:P.limeInk, background:P.lime, border:'none', boxShadow:`0 0 0 1px ${P.lime}, 0 8px 22px ${P.lime}26` },
    ghost:{ color:P.ink, background:'transparent', border:`1px solid ${P.line}` },
    danger:{ color:'#fff', background:'#E5484D', border:'none' },
    accent:{ color:'#fff', background:P.accent, border:'none' },
  };
  return <button onClick={disabled?undefined:onClick} style={{ ...base, ...variants[variant], ...style }}>{children}</button>;
}
function Chip({ children, tone='soft', style }){
  const P = useP();
  const map = {
    soft:{ bg:'rgba(255,255,255,.06)', fg:P.ink2, bd:P.line },
    accent:{ bg:P.primarySoft, fg:P.lime, bd:'transparent' },
    open:{ bg:P.goodBg, fg:P.good, bd:'transparent' },
    closed:{ bg:'rgba(255,255,255,.05)', fg:P.ink3, bd:'transparent' },
    upcoming:{ bg:P.infoBg, fg:P.info, bd:'transparent' },
    qualifier:{ bg:P.primarySoft, fg:P.lime, bd:'transparent' },
    finals:{ bg:P.infoBg, fg:P.info, bd:'transparent' },
    you:{ bg:P.primarySoft, fg:P.lime, bd:'transparent' },
  };
  const t = map[tone]||map.soft;
  return <span style={{ fontFamily:P.mono, fontWeight:700, fontSize:9.5, letterSpacing:'0.1em', textTransform:'uppercase', padding:'3px 9px', borderRadius:999, background:t.bg, color:t.fg, border:`1px solid ${t.bd}`, whiteSpace:'nowrap', ...style }}>{children}</span>;
}
function Avatar({ name, size=34, onClick }){
  const P = useP();
  return <div onClick={onClick} style={{ width:size, height:size, borderRadius:'50%', background:P.raise, border:`1px solid ${P.line}`, display:'flex', alignItems:'center', justifyContent:'center', fontFamily:P.disp, fontWeight:600, fontSize:size*0.36, color:P.ink, flexShrink:0, cursor:onClick?'pointer':'default' }}>{(name||'').slice(0,2).toUpperCase()}</div>;
}
function Stars({ n, size=13, onPick }){
  const P = useP();
  return <span style={{ display:'inline-flex', gap:2, fontSize:size }}>{[1,2,3,4,5].map(s=>(
    <span key={s} onClick={onPick?()=>onPick(s):undefined} style={{ color:s<=n?P.lime:'rgba(255,255,255,.16)', cursor:onPick?'pointer':'default', lineHeight:1 }}>★</span>))}</span>;
}
function Divider({ m=20 }){ const P=useP(); return <div style={{ height:1, background:P.line, margin:`${m}px 0` }} />; }
function Card({ children, style, onClick, hover }){
  const P = useP();
  const [h,setH] = React.useState(false);
  return <div onClick={onClick} onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)}
    style={{ background:P.card, border:`1px solid ${hover&&h?'rgba(214,255,62,.5)':P.line}`, borderRadius:16, transition:'border-color .15s', cursor:onClick?'pointer':'default', ...style }}>{children}</div>;
}
function Field({ label, value, onChange, placeholder, type='text', textarea, hint, optional }){
  const P = useP();
  const cls = { width:'100%', background:P.raise, border:`1px solid ${P.line}`, borderRadius:12, padding:'12px 14px', fontFamily:P.disp, fontWeight:500, fontSize:14.5, color:P.ink, outline:'none', boxSizing:'border-box' };
  return (
    <div>
      {label && <label style={{ display:'block', fontFamily:P.mono, fontWeight:400, fontSize:10, letterSpacing:'0.16em', textTransform:'uppercase', color:P.ink3, marginBottom:7 }}>{label}{optional && <span style={{ opacity:.7 }}> · optional</span>}</label>}
      {textarea
        ? <textarea value={value} readOnly={!onChange} placeholder={placeholder} onChange={onChange&&(e=>onChange(e.target.value))} style={{ ...cls, height:80, resize:'none' }} />
        : <input type={type} value={value} readOnly={!onChange} placeholder={placeholder} onChange={onChange&&(e=>onChange(e.target.value))} style={cls} />}
      {hint && <p style={{ fontFamily:P.mono, fontSize:11, color:P.ink3, margin:'7px 0 0', lineHeight:1.5 }}>{hint}</p>}
    </div>
  );
}
function Toggle({ on, onChange }){
  const P = useP();
  return <div onClick={()=>onChange&&onChange(!on)} style={{ width:44, height:24, borderRadius:999, background:on?P.lime:'rgba(255,255,255,.16)', cursor:'pointer', display:'flex', alignItems:'center', padding:2, transition:'background .15s', flexShrink:0 }}>
    <div style={{ width:20, height:20, borderRadius:'50%', background: on?P.limeInk:'#fff', transform:on?'translateX(20px)':'translateX(0)', transition:'transform .18s' }} />
  </div>;
}
function Modal({ title, subtitle, children, onClose }){
  const P = useP();
  return (
    <div onClick={onClose} style={{ position:'fixed', inset:0, zIndex:60, background:'rgba(4,5,7,.66)', backdropFilter:'blur(3px)', display:'flex', alignItems:'center', justifyContent:'center', padding:20 }}>
      <div onClick={e=>e.stopPropagation()} style={{ width:'100%', maxWidth:330, background:P.panel, borderRadius:18, border:`1px solid ${P.line}`, padding:'22px 22px 24px', boxShadow:'0 24px 60px rgba(0,0,0,.6)' }}>
        <h2 style={{ fontFamily:P.disp, fontWeight:700, fontSize:22, letterSpacing:-0.4, margin:0, color:P.ink }}>{title}</h2>
        {subtitle && <p style={{ fontFamily:P.mono, fontSize:12, color:P.ink2, margin:'6px 0 0' }}>{subtitle}</p>}
        <div style={{ marginTop:18 }}>{children}</div>
      </div>
    </div>
  );
}
function GradePills({ grades, value, onPick, wrap=true }){
  const P = useP();
  return (
    <div style={{ display:'flex', gap:7, flexWrap:wrap?'wrap':'nowrap' }}>
      {grades.map(g=>{
        const sel = value===g;
        return <button key={g} onClick={()=>onPick&&onPick(g)} style={{ fontFamily:P.disp, fontWeight:600, fontSize:13.5, padding:'8px 13px', borderRadius:10, cursor:'pointer', border:`1px solid ${sel?P.lime:P.line}`, background:sel?P.lime:P.raise, color:sel?P.limeInk:P.ink2, transition:'all .12s' }}>V{g}</button>;
      })}
    </div>
  );
}
function ColourSwatches({ value, onPick }){
  const P = useP();
  return (
    <div style={{ display:'flex', gap:11, flexWrap:'wrap' }}>
      {Object.keys(HOLD).filter(k=>k!=='White').map(name=>{
        const sel = value===name;
        return <button key={name} onClick={()=>onPick&&onPick(name)} title={name} style={{ width:32, height:32, borderRadius:'50%', background:HOLD[name], cursor:'pointer', border:`2.5px solid ${sel?P.lime:'transparent'}`, transform:sel?'scale(1.12)':'none', transition:'all .12s' }} />;
      })}
    </div>
  );
}

Object.assign(window, {
  FONTS, APEX, THEMES, ThemeCtx, useP, HOLD,
  RANKS, MAGNUS_RANK, getRank, GRADE_POINTS, RankIcon, RankBadge,
  fmtDate, fmtDateLong, Sky, Watermark, Eyebrow, Btn, Chip, Avatar, Stars, Divider,
  Card, Field, Toggle, Modal, GradePills, ColourSwatches,
});
